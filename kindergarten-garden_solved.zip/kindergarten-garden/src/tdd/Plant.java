package tdd;

public enum Plant {
	RADISHES, CLOVER, GRASS, VIOLETS
}
